from setuptools import setup
import os
from glob import glob

package_name = 'homework_package'
setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),  # To include launch files
        ('share/' + package_name + '/worlds', glob('worlds/*.wbt')),        # To include world files
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='sazorii',
    maintainer_email='sazorii@todo.todo',
    description='Simulated environment for CS460/560 project',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [],
    },
)


from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch_ros.actions import Node
import os

def generate_launch_description():
    # Path to the Webots world file
    world_file = os.path.join(
        os.getenv('HOME'), 'workspaces', 'src', 'Homework_Package', 'worlds', 'myMap.wbt'
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            'world',
            default_value=world_file,
            description='Path to the Webots world file'
        ),
        Node(
            package='webots_ros2_driver',
            executable='driver',
            name='webots_driver',
            output='screen',
            parameters=[{'world': world_file}]
        ),
    ])
